﻿param([string]$DataRoot)
$ErrorActionPreference = 'Stop'
$petId = 'han-g-dragon'
$source = Join-Path $PSScriptRoot $petId
$sourceManifest = Join-Path $source 'pet.json'
$sourceSheet = Join-Path $source 'spritesheet.webp'
$expectedSheet = '752E888E3E76045D3D411E0FA8278DBE3A487FAE16C8ABAC4D4C2C25705BDB59'
function Get-PetHash([string]$Path) {
    $stream = [IO.File]::OpenRead($Path)
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($algorithm.ComputeHash($stream)).Replace('-','') }
    finally { $algorithm.Dispose(); $stream.Dispose() }
}
try {
    if (-not (Test-Path -LiteralPath $sourceManifest -PathType Leaf) -or -not (Test-Path -LiteralPath $sourceSheet -PathType Leaf)) {
        throw '安裝檔不完整。請先將整個 ZIP 解壓縮，再執行安裝。'
    }
    $manifest = Get-Content -LiteralPath $sourceManifest -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.id -ne $petId -or $manifest.spriteVersionNumber -ne 2 -or $manifest.spritesheetPath -ne 'spritesheet.webp' -or (Get-PetHash $sourceSheet) -ne $expectedSheet) {
        throw '寵物檔案不完整或已被更動，請重新下載安裝包。'
    }
    if (-not $DataRoot) {
        $DataRoot = if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path $env:USERPROFILE '.codex' }
    }
    $destination = Join-Path ([IO.Path]::GetFullPath($DataRoot)) "pets\$petId"
    $existingSheet = Join-Path $destination 'spritesheet.webp'
    $existingManifest = Join-Path $destination 'pet.json'
    if (Test-Path -LiteralPath $destination) {
        if (-not (Test-Path -LiteralPath $existingSheet -PathType Leaf) -or -not (Test-Path -LiteralPath $existingManifest -PathType Leaf)) {
            throw '發現不完整的既有寵物資料夾，已保留原檔。請先將該資料夾移走，再重新安裝。'
        }
        if ((Get-PetHash $existingManifest) -ne (Get-PetHash $sourceManifest)) {
            throw '已有同名但內容不同的寵物，已保留原檔。請先備份並移走該寵物，再重新安裝。'
        }
        if ((Get-PetHash $existingSheet) -eq $expectedSheet) {
            Write-Host '憨G龍已安裝，檔案完整。' -ForegroundColor Green
        } else {
            Write-Host '這台電腦已有另一個版本的憨G龍。'
            if ((Read-Host '輸入 1 備份並更新；其他輸入取消') -ne '1') {
                Write-Host '已取消，原本的憨G龍保持不變。'
                return
            }
            $backup = Join-Path $destination ('spritesheet.backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '.webp')
            $staged = Join-Path $destination ('spritesheet.install-' + [Guid]::NewGuid().ToString('N') + '.webp')
            Copy-Item -LiteralPath $sourceSheet -Destination $staged
            if ((Get-PetHash $staged) -ne $expectedSheet) { throw '複製未完成，原本的寵物保持不變。' }
            [IO.File]::Replace($staged,$existingSheet,$backup)
            Write-Host '已更新憨G龍，舊版已備份。' -ForegroundColor Green
        }
    } else {
        New-Item -ItemType Directory -Path $destination -Force | Out-Null
        Copy-Item -LiteralPath $sourceSheet -Destination $existingSheet
        Copy-Item -LiteralPath $sourceManifest -Destination $existingManifest
        Write-Host '憨G龍安裝完成！' -ForegroundColor Green
    }
    if ((Get-PetHash $existingSheet) -ne $expectedSheet -or (Get-PetHash $existingManifest) -ne (Get-PetHash $sourceManifest)) {
        throw '安裝後的檔案核對未通過，請重新安裝。'
    }
    Write-Host ''
    Write-Host '請開啟 Codex，前往「設定 → Pets」，選擇「憨G龍」，再按「Wake Pet／喚醒寵物」。'
    Write-Host '更新後請在「設定 → Pets」按圓形箭頭「Refresh／重新整理」，再選回憨G龍。'
    Write-Host '把滑鼠移開牠，待機時會播放動態舌頭；移到牠身上則會吐火冒白菸。'
} catch {
    Write-Host ('安裝未完成：' + $_.Exception.Message) -ForegroundColor Yellow
    exit 1
}
