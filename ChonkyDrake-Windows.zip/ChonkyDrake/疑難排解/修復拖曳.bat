@echo off
chcp 65001 >nul
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0repair.ps1"
set "repairExit=%errorlevel%"
pause
exit /b %repairExit%
