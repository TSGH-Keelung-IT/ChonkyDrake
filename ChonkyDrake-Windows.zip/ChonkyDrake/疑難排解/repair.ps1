﻿param([switch]$Restore)
$ErrorActionPreference = 'Stop'
$stateDirectory = Join-Path $env:LOCALAPPDATA 'ChonkyDrake'
$lastRecordPath = Join-Path $stateDirectory 'pet-window.json'
try {
    Add-Type -Path (Join-Path $PSScriptRoot 'PetInputRepair.dll')
    if ($Restore) {
        if (-not (Test-Path -LiteralPath $lastRecordPath)) { throw '沒有找到可還原的資料。若已重開 Codex，就不需要再次還原。' }
        $saved = Get-Content -LiteralPath $lastRecordPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $window = New-Object PetInputRepair.WindowInfo
        foreach ($name in @('Handle','StartTicks','Style','ExStyle','ProcessId','Left','Top','Right','Bottom','PointX','PointY','Visible','ProcessPath','Title','ClassName')) { $window.$name = $saved.before.$name }
        $null = [PetInputRepair.Native]::RestoreLayered($window)
        Write-Host '已還原。' -ForegroundColor Green
        return
    }
    Write-Host '憨G龍拖曳修復' -ForegroundColor Cyan
    Write-Host '保持 Codex 和桌面寵物開啟。請把滑鼠移到龍的肚子上，保持不動。'
    for ($seconds=7; $seconds -gt 0; $seconds--) {
        Write-Host ("`r{0} 秒後開始... " -f $seconds) -NoNewline
        Start-Sleep -Seconds 1
    }
    Write-Host ''
    $window = [PetInputRepair.Native]::FindAtPointer()
    if (($window.ExStyle -band [PetInputRepair.Policy]::Layered) -eq 0) {
        Write-Host '目前的寵物視窗不適用此修復，沒有變更。' -ForegroundColor Yellow
        return
    }
    New-Item -ItemType Directory -Path $stateDirectory -Force | Out-Null
    $record = [ordered]@{before=$window; createdAt=(Get-Date).ToString('o'); validation='pending'}
    [IO.File]::WriteAllText($lastRecordPath,($record|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false))
    $null = [PetInputRepair.Native]::RemoveLayered($window)
    Write-Host '請現在測試拖曳，再回到這個視窗。'
    Write-Host '如果寵物周圍透明區域擋住點擊，請選擇還原。'
    if ((Read-Host '輸入 1 保留修復；其他輸入立即還原') -eq '1') {
        $record.validation='kept'
        Write-Host '已保留這次修復。重開 Codex 後若再發生，可重新執行。' -ForegroundColor Green
    } else {
        $null = [PetInputRepair.Native]::RestoreLayered($window)
        $record.validation='restored'
        Write-Host '已還原。'
    }
    [IO.File]::WriteAllText($lastRecordPath,($record|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false))
} catch {
    Write-Host '未完成修復。請確認桌面寵物已開啟，並在倒數時把滑鼠放在龍的肚子上。' -ForegroundColor Yellow
    Write-Host '如果 Codex 已重新啟動，舊的還原資料就不再適用。'
    Write-Host ('詳細訊息：' + $_.Exception.Message)
    Write-Host '如需撤回變更，可執行「還原拖曳.bat」，或完全退出再重開 Codex。'
    exit 1
}
